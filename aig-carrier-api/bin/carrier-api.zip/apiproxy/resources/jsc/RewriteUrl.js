context.setVariable("target.copy.pathsuffix",false);
var target = context.getVariable("url");
context.setVariable("target.url",target);
